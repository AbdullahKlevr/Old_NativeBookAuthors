<footer>
   <div class="container">
   	<div class="row">
   		<div class="col-lg-12">
			<div class="copyright">
			<p>Copyright © <?php echo date("Y")?> <?php echo $brand;?>. All rights reserved.</p>
			<img src="assets/images/payments.webp" alt="" loading="lazy" width="100px" height="100px">
			<!-- <div class="links">
				<a href="terms.php">Terms & Condition</a>
				<a href="privacy-policy.php">Privacy Policy</a>
			</div> -->
			</div>
		</div>
   	</div>
   </div>
</footer>